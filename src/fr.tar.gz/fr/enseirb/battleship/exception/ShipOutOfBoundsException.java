package fr.enseirb.battleship.exception;

public class ShipOutOfBoundsException extends Exception {

	public ShipOutOfBoundsException() {
		// TODO Auto-generated constructor stub
	}

}
