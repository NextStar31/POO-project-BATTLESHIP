package fr.enseirb.battleship.exception;

public class ShipConfigurationException extends Exception {

	public ShipConfigurationException() {
		// TODO Auto-generated constructor stub
	}

}
