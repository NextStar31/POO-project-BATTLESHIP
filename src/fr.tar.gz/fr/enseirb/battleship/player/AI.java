package fr.enseirb.battleship.player;

public class AI extends Player {

	public AI() {
		// TODO Auto-generated constructor stub
	}

}
