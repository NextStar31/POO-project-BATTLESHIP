package fr.enseirb.battleship.player;

import fr.enseirb.battleship.grid.Grid;

public class Player {
	
	private int id;
	private int opponentId;
	private Grid gridPlayer;
	private Grid gridOpponent;

	public Player() {
		// TODO Auto-generated constructor stub
	}

}
