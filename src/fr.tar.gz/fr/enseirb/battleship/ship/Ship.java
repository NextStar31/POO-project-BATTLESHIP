package fr.enseirb.battleship.ship;

public class Ship {
	
	private int ownerId;
	private int shipId;
	private int totalNumberLeft;
	private int numberOfCells;

	public Ship() {
		// TODO Auto-generated constructor stub
	}

}
