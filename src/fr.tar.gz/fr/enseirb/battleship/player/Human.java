package fr.enseirb.battleship.player;

public class Human extends Player {

	public Human() {
		// TODO Auto-generated constructor stub
	}

}
