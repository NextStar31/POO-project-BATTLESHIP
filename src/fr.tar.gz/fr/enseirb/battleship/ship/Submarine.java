package fr.enseirb.battleship.ship;

public class Submarine extends Ship {

	public Submarine() {
		// TODO Auto-generated constructor stub
	}

}
