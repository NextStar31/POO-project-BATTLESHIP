package fr.enseirb.battleship.ship;

public class Battleship extends Ship {

	public Battleship() {
		// TODO Auto-generated constructor stub
	}

}
