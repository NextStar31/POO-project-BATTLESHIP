package fr.enseirb.battleship.exception;

public class ShipOverlapException extends Exception {

	public ShipOverlapException() {
		// TODO Auto-generated constructor stub
	}

}
