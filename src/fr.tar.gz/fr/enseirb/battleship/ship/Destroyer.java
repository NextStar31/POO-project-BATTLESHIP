package fr.enseirb.battleship.ship;

public class Destroyer extends Ship {

	public Destroyer() {
		// TODO Auto-generated constructor stub
	}

}
