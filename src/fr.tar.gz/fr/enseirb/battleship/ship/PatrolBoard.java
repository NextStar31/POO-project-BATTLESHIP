package fr.enseirb.battleship.ship;

public class PatrolBoard extends Ship {

	public PatrolBoard() {
		// TODO Auto-generated constructor stub
	}

}
