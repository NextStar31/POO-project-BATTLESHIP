package fr.enseirb.battleship.ship;

public class AircraftCarrier extends Ship {

	public AircraftCarrier() {
		// TODO Auto-generated constructor stub
	}

}
