package fr.enseirb.battleship;

public class App extends Exception {
	public static void main(String[] args) {
		

	}

}
