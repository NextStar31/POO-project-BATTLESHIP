package fr.enseirb.battleship.grid;

import fr.enseirb.battleship.ship.Ship;


public class Cell {
	
	private int x;
	private int y;
	private boolean state; // 0 -> untouched, 1 -> touched
	private Ship content;

	public Cell() {
		// TODO Auto-generated constructor stub
	}

}
